<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form </title>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

    <!--font awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css">

    <!-- Main Style -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
  <?php
$servername='localhost';
$username='root';
$password='';
$dbname = "diu";
$conn=mysqli_connect($servername,$username,$password,$diu);
if(!$conn){
   die('Could not Connect My Sql:' .mysql_error());
}
?>


  <header>
    <h2 class="text-center"> Registration Form </h2>
  </header>

    <section id="form-area">
            <div class="row no-gutters">
                <div class="col-md-8">
                    <div class="banner">
                        <div class="overlay"></div>
                    </div>
                    <?php
include_once 'database.php';
if(isset($_POST['save']))
{
	 $name = $_POST['Student_Name'];
	 $id = $_POST['Student_ID'];
	 $age = $_POST['Student_age'];
	 $username = $_POST['Student_username'];
   $password = $_POST['Password'];
	 $sql = "INSERT INTO CreativeLearner (Student_Name,Student_ID,Student_age,Student_username,Password)
	 VALUES ('$name','$id','$age','$username','$password')";
	 if (mysqli_query($conn, $sql)) {
		echo "Data insertion successfull !";
	 } else {
		echo "Data insertion is not successfull" . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}
?>

                </div>
                <div class="col-md-4 text-light">
                    <div class="signupform">
                      <div class="signup-content">
                        <h2>Signup Now</h2>
                        <h4>Creating an account is free..</h4>
                        <p>and won't take longer than a couple os seconds</p>

                            <form>
                                <div class="form-group">
                                  <label>Your Name  </label>
                                  <input type="text" class="form-control">
                                </div>
                                <div class="form-group">
                                  <label> Email </label>
                                  <input type="email" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label> Password </label>
                                    <input type="password" class="form-control">
                                  </div>
                                  <div class="form-group">
                                    <label> Confirm Password </label>
                                    <input type="password" class="form-control">
                                  </div>
                                <div class="form-group form-check">
                                  <input type="checkbox" class="form-check-input">
                                  <label class="form-check-label">I Accept to the Terms & Conditions</label>
                                </div>
                                <button type="submit" class="btn p-2"> Submit </button>
                              </form>
                              <p class="text-center mt-4 login-text"> Or Login With</p>
                              <div class="social-icon text-center">
                                <i class="fab fa-facebook-f fb"></i>
                                <i class="fab fa-twitter twit"></i>
                                <i class="fab fa-instagram insta"></i>
                                <i class="fab fa-linkedin-in linked"></i>
                              </div>

                        </div>
                    </div>
                </div>
            </div>
    </section>



    <!-- Jquery -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Bootstrap Js-->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>
</html>
